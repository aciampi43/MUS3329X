#!/usr/bin/env python3
# encoding: utf-8
from pyo import *
from LibrairieProjet import *

s = Server(sr=44100, nchnls=2, buffersize=512, duplex=1).boot()


class Partition:
    def __init__(self):
        self.timer = 0
        
        #Elements (Organum SuperSaw)
        self.pElements = Elements()
        
        # Bass
        self.pBass = PartitionBass(maxrep=11, transpose=0, vol=10, time=0.75)

        # Alto
        self.pAlto = PartitionAlto(mel =1, transpose=-2, vol=3, time=1)
       
        # Soprano
        self.pSoprano = PartitionSoprano(mel=1, transpose=3, vol=3, time=1)
        
        #Cloche
        self.pCloche = PartitionCloche(mel = 1, transpose=10,   vol=1, time=0.90)
        self.pat = Pattern(self.score, 1).play()

    def score(self):
        if self.timer == 0:
            self.pElements.setVolume(0.05)
            self.pElements.out()
            self.pAlto.setMelody(1)
        if self.timer==5:
            self.pAlto.play()
        elif self.timer == 15:
            self.pAlto.setMelody(2)
            self.pAlto.play()
        elif self.timer == 22:
            self.pAlto.setMelody(3)
            self.pAlto.play()
        elif self.timer == 30:
            self.pAlto.setMelody(4)
            self.pAlto.play()
        elif self.timer == 48:
            self.pSoprano.setMelody(1)
            self.pSoprano.play()
        elif self.timer == 55:
            self.pSoprano.play()
        elif self.timer == 62:
            self.pElements.setVolume(0.06)
        elif self.timer == 65:
            self.pSoprano.setVolume(2.5)
            self.pSoprano.setMelody(2)
            self.pSoprano.play()
        elif self.timer == 70:
            self.pSoprano.setMelody(3)
            self.pSoprano.play()
        elif self.timer ==78:
            self.pCloche.play()
        elif self.timer == 84:
            self.pBass.play()
        elif self.timer == 90:
            self.pElements.setVolume(0.10)
        elif self.timer ==98:
            self.pCloche.play()
            self.pCloche.setMelody(2)
            self.pCloche.setVolume(0.8)
        elif self.timer == 103:
            self.pBass.setVolume(10)
        elif self.timer == 105:
            self.pElements.setVolume(0.01)
        elif self.timer ==108:
            self.pCloche.play()
            self.pCloche.setVolume(0.4)
        elif self.timer == 109:
            self.pBass.setVolume(8)
        elif self.timer == 115:
            self.pBass.setVolume(5)
        elif self.timer ==118:
            self.pCloche.play()
            self.pCloche.setVolume(0.2)
        elif self.timer == 121:
            self.pBass.setVolume(3)
        elif self.timer == 127:
            self.pBass.setVolume(2)
        elif self.timer == 130:
            self.pBass.setVolume(1)
        elif self.timer == 131:
            self.pSoprano.setMelody(6)
            self.pSoprano.setVolume(3)
            self.pSoprano.play()
        elif self.timer == 138:
            self.pSoprano.setMelody(7)
            self.pSoprano.setVolume(3)
            self.pSoprano.play()

        self.timer += 1
        
# La methode getSound() fait la somme des signaux de toutes les voix
    def getSound(self):
        return self.pAlto.getSound() + self.pCloche.getSound() + self.pBass.getSound() + self.pSoprano.getSound()

# On cree la partition globale
partition = Partition()

# On passe le son dans une petite reverberation!
reverb = STRev(partition.getSound(), inpos=0.50, revtime=1, cutoff=5000, bal=0.25).out()

s.gui(locals())