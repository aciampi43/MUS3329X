

from pyo import *
"""
__________________________________________________________________
Classes Organum pour jouer quintes (SuperSaw)
___________________________________________________________________
"""

class Elements:
    "Joue quinte (Organum) avec SuperSaw"
    #Constructeur pour Elements
    def __init__(self, note=43, dur=160, vol=1):
        self.note = note
        self.dur = dur
        self.vol = vol
        self.q= [midiToHz(self.note), midiToHz(self.note+7)]
        
    #Utilisation de LinTable et TableRead.pour obtenir un profil dynamique
        self.env = LinTable([(0,0.0000),(380,0.2574),(881,0.2772),(1590,0.1881),(1901,0.11),(2454,0.4851),(3249,0.8663),(4044,0.9901),(5236,0.9455),(6239,0.8465),(6792,0.5941),(7206,0.2327),(8192,0.0000)])
        self.b=TableRead(self.env, freq=1/dur, mul=1)
        self.b1=TableRead(self.env, freq=1/dur, mul=1)
        self.env.graph()
        self.a1 = SuperSaw(freq=self.q, detune=0.50, bal=0.70, mul= 0.3*self.b, add=0)
        self.a2 = SuperSaw(freq=self.q, detune=0.50, bal=0.70, mul= 0.3*self.b +2*self.b1, add=0)

    def out(self, x=0):
            self.b.play()
            self.b1.play()
            self.a1.out(x)
            self.a2.out()
            return self
            
    def setNote(self,note):
        self.note=note
        
    
    def sig(self):
        return self.organum.sig()
        
    #Méthode pour changer le volume
    def setVolume(self, vol):
        self.b.mul=vol
        self.b1.mul=vol


"""
__________________________________________________________________
Classes Voice, utilisée pour créer voix synthetiques
___________________________________________________________________


Ici on définit les formants pour les regitres SATB et la
classe Voice qui permets de contruire Instruments imitants 
les registres SATB
"""

bass_formants = [(550, 1200, 2500, 3000), (-18, -25, -35, -45), (4.69, 8.06, 10.97, 12.81)]
tenor_formants = [(750, 1450, 2590, 3280), (-18, -35, -60, -69), (4.69, 8.06, 10.97, 12.81)]
alto_formants = [(950, 1570, 3150, 4370), (-18, -35, -60, -69), (4.69, 8.06, 10.97, 12.81)]
soprano_formants = [(1050, 1670, 3150, 4570), (-18, -35, -60, -79), (4.69, 8.06, 10.97, 12.81)]

class Voice:
    def __init__(self, freq=80, register=bass_formants, mul=1):
        
        self.register = register
        self.vib = Sine(Randi(4,5,.1), mul=.005, add=1)
        self.freq = Sig(freq, mul=self.vib)
        self.f0 = Sine(self.freq, mul=0.05)
        self.pulses = Blit(freq=self.freq, harms=5000/self.freq, mul=20)
        self.input = ButLP(self.pulses+self.f0, 2000)
        self.cf1 = Resonx(self.input, self.register[0][0], self.register[2][0], stages=3, mul=DBToA(Sig(self.register[1][0])))
        self.cf2 = Resonx(self.input, self.register[0][1], self.register[2][1], stages=3, mul=DBToA(Sig(self.register[1][1])))
        self.cf3 = Resonx(self.input, self.register[0][2], self.register[2][2], stages=3, mul=DBToA(Sig(self.register[1][2])))
        self.cf4 = Resonx(self.input, self.register[0][3], self.register[2][3], stages=3, mul=DBToA(Sig(self.register[1][3])))
        self.cf5 = Resonx(self.input, self.register[0][3]+1000, self.register[2][3], stages=3, mul=DBToA(Sig(self.register[1][3])))
        self.formants = Chorus(self.f0 + self.cf1 + self.cf2 + self.cf3 + self.cf4 + self.cf5, mul=mul)

    def out(self):
        self.formants.out()
        return self

    def sig(self):
        return self.formants
        
    def out(self, chnl=0):
        self.formants.out(chnl)
        return self

    def setFreq(self, x, time=0.05):
        if time <= 0:
            self.freq.value = x
        else:
            self.freq.set("value", x, time)


"""
__________________________________________________________________
Classes pour OmTare: InstBass
___________________________________________________________________
"""

class InstBass:
    #Constructeur pour InstBass
    def __init__(self, feedback=0.08):
        self.feedback = feedback
        self.envelope = Fader(fadein=0.1, fadeout=0.1, mul=10)
        self.bass = Voice(freq=100, register=bass_formants, mul=self.envelope)

    # Cette fonction est appelee pour jouer une note.
    def play(self, freq, dur, amp):
        self.bass.setFreq(freq)
        self.envelope.dur = dur
        self.envelope.mul = amp
        self.envelope.play()
    
    def sig(self):
        return self.bass.sig()

class OmTare:
    #Mantra OmTare
    def __init__(self,transpose=0):
        pit1 = midiToHz([x + transpose for x in [36, 43, 43, 43, 43, 43, 47, 43, 43, 43, 36]])

# frequence, duree, amplitude
        self.notes = [(pit1[0], 0.5, 0.05), (pit1[1], 0.5, 0.08), (pit1[2], 0.5, 0.05), (pit1[3], 0.5, 0.05), (pit1[4], 1.0, 0.08), 
            (pit1[5], 0.5, 0.05), (pit1[6], 0.5, 0.08), (pit1[7], 0.5, 0.05), (pit1[8], 0.5, 0.08), (pit1[9], 0.5, 0.08),
            (pit1[10], 0.6, 0.04)]
            
    def chooseMelody(self):
        phrase = self.notes
        return phrase





# Partition pour bass
class PartitionBass:
    def __init__(self, maxrep=2, transpose=0, vol = 1, time=1.5):
        # melodies
        self.omtare =OmTare()
        # instruments
        self.bass = InstBass()
        self.maxrep= maxrep
        self.transpose=transpose
        self.vol = vol
        self.time=time
        #le compte de repetition
        self.rep=1
        # Le compte des notes dans la melodie
        self.count = 0
        self.omtare = OmTare(transpose=self.transpose)    
        # La liste de notes a jouer
        self.notes = self.omtare.chooseMelody()


        # self.newNote est appelee a chaque nouvelle note.
        self.player = Pattern(self.newNote, time=self.time)

    def newNote(self):
        # On recupere la note dans la liste et on active une note a l'instrument Bass.
        if self.count < len(self.notes): 
            note = self.notes[self.count]
            freq = note[0]
            dur = note[1]*1.25
            amp = note[2]*self.vol
            self.bass.play(freq, dur*self.time, amp)
       #Pattern pour suivre la sequence rythmique des durees
            self.player.time = dur*self.time


        # On incremente le compte
        self.count += 1
        # Si au bout de la liste...
        if self.count == len(self.notes):
            # On remet le compte a zero
            self.count = 0
            #On incremente le nombre de repetition
            self.rep+=1
            #Si au bout du compte des repetitions...
            if self.rep>self.maxrep:
                #On arrête
                self.player.stop()


     # Methode pour activer la partition de la voix bass.
    def play(self):
        self.player.play()

    # Methode pour recuperer le son de la voix bass.
    def getSound(self):
        return self.bass.sig()
        
    # Méthode pour changer le volume
    def setVolume(self, x):
        self.vol=x
            
    # Méthode pour changer le tempo
    def setTime(self, x):
        self.time=x

"""
__________________________________________________________________
Classes Organum pour jouer quintes (Tenor voice)
___________________________________________________________________
"""

class OrganumTen:
    "Joue quinte avec voix de ténor"
    #Constructeur pour Organum
    def __init__(self, note=36, dur=300, vol=1):
        self.note = note
        self.dur = dur
        self.vol=vol
        self.q= [midiToHz(self.note), midiToHz(self.note+7)]
        self.env = LinTable([(0,0.0000),(380,0.2574),(881,0.2772),(1590,0.1881),(1901,0.11),(2454,0.4851),(3249,0.8663),(4044,0.9901),(5236,0.9455),(6239,0.8465),(6792,0.5941),(7206,0.2327),(8192,0.0000)])
        self.b=TableRead(self.env, freq=1/dur, mul=1)
        self.env.graph()
        self.organum = Voice(freq=self.q, register=tenor_formants, mul= 2*self.b)
        self.rev = STRev(self.organum.sig(), bal=0.5)
        
    def sig(self):
        return self.organum.sig()
    def out(self, x=0):
        self.b.play()
        self.rev.out(x)
        return self
            
    def setNote(self, note):
        self.note=note
        
    def setDuration(self, dur):
        self.duration=dur
        
    def play(self):
        self.b.play()


"""
__________________________________________________________________
Classes pour Ave Maris Stella: InstAlto
___________________________________________________________________
"""

#Chant d'extrait de Ave Maris Stella
class InstAlto:
    #Constructeur pour InstAlto
    def __init__(self, feedback=0.08):
        self.feedback = feedback
        self.envelope = Fader(fadein=0.3, fadeout=0.05, mul = 0.5)
        self.alto = Voice(freq=100, register=alto_formants, mul=self.envelope)
        self.cho = Chorus(self.alto.sig())
    # Cette fonction est appelee pour jouer une note.
    def play(self, freq, dur, amp):
        self.alto.setFreq(freq)
        self.envelope.dur = dur
        self.envelope.mul = amp
        self.envelope.play()
    
    def sig(self):
        return self.cho


class AMS:
    #Phrases from Ave Maris Stella
    def __init__(self, transpose=0):
        pit1 = midiToHz([x + transpose for x in  [62, 69, 71, 67, 69, 71, 74, 72, 71, 69, 67, 69]])
        pit2 = midiToHz([x + transpose for x in [69, 69, 62, 64, 67, 65, 64, 62]])
        pit3 = midiToHz([x + transpose for x in[65, 64, 67, 69, 69, 62, 64, 65, 62, 60]])
        pit4 = midiToHz([x + transpose for x in[64, 67, 64, 65, 64, 62]])
    
 # frequence, duree, amplitude, velocity
    # Ave Maris Stella
        self.notes1 = [(pit1[0], 0.5, 0.05), (pit1[1], 0.5, 0.07), (pit1[2], 0.5, 0.05), (pit1[3], 0.5, 0.05), (pit1[4], 0.5, 0.07), (pit1[5], 0.5, 0.05), (pit1[6], 0.5, 0.08), (pit1[7], 0.5, 0.07), (pit1[8], 0.5, 0.06), (pit1[9], 0.5, 0.05), (pit1[10], 0.5, 0.04), (pit1[11], 0.8, 0.05)]
    #Dei Mater Alma
        self.notes2 = [(pit2[0], 0.5, 0.05), (pit2[1], 0.5, 0.05), (pit2[2], 0.5, 0.06), (pit2[3], 0.5, 0.05), (pit2[4], 0.5, 0.05), (pit2[5], 0.5, 0.06), (pit2[6], 0.5, 0.07),(pit2[7], 0.7, 0.06)] 
    #Atque semper Virgo
        self.notes3 = [(pit3[0], 0.5, 0.08), (pit3[1], 0.5, 0.07), (pit3[2], 0.5, 0.05), (pit3[3], 0.5, 0.05), (pit3[4], 0.5, 0.05), (pit3[5], 0.5, 0.09), (pit3[6], 0.5, 0.08), (pit3[7], 0.5, 0.07), (pit3[8], 0.5, 0.06), (pit3[9],0.7, 0.05)] 
    #Felix coeli porta
        self.notes4 = [(pit4[0], 0.5, 0.05), (pit4[1], 0.5, 0.05), (pit4[2], 0.5, 0.05), (pit4[3], 0.5, 0.05), (pit4[4], 0.8, 0.07), (pit4[5], 1.2, 0.06)] 
       
    def chooseMelody(self, mel):
        if mel ==1:
            phrase = self.notes1
        elif mel ==2:
            phrase = self.notes2
        elif mel ==3:
            phrase = self.notes3
        elif mel ==4:
            phrase = self.notes4
                        
        return phrase


# Partition pour la voix de alto
class PartitionAlto:
    def __init__(self, mel=1, transpose=0, vol=1, time=1):
        # instruments
        self.alto = InstAlto()
        self.transpose=transpose
        self.vol=vol
        self.time=time
        # Le numero de la melodie
        self.melody = mel
        # Le compte des notes dans la melodie
        self.count = 0
        # melodies
        self.ams = AMS(transpose=self.transpose)

        # La liste de notes a jouer
        self.notes = self.ams.chooseMelody(self.melody)

        # self.newNote est appelee a chaque nouvelle note.
        self.player = Pattern(self.newNote, time=0.5)
        
    def newNote(self):
        # On recupere la note dans la liste et on active une note a l'instrument alto.
        if self.count < len(self.notes): 
            note = self.notes[self.count]
            freq = note[0]
            dur = note[1] * 1.25
            amp = note[2]*self.vol
            self.alto.play(freq, dur*self.time, amp)
        # On ajuste le "time" du Pattern pour suivre la sequence rythmique des durees
            self.player.time = dur*self.time

        # On incremente le compte
        self.count += 1
        # Si au bout de la liste...
        if self.count == len(self.notes) + 1:
            # On arrête
            self.player.stop()
            print("Playing alto melody # %d" % self.melody)
            
            self.count=0

            
    # Methode pour activer la partition de la voix alto.
    def play(self):
        self.player.play()

    # Methode pour recuperer le son de la voix .
    def getSound(self):
        return self.alto.sig()
        
    # Méthode pour changer mélodies
    def setMelody(self, x):
        self.melody = x
        self.notes = self.ams.chooseMelody(self.melody)
        
    # Méthode pour changer le volume
    def setVolume(self, x):
        self.vol=x
        
    # Méthode pour changer le tempo
    def setTime(self, x):
        self.time=x




"""________________________________________________________________
##Classes pour SalveRegina: InstSoprano ##
_________________________________________________________________
"""

#Chant d'extrait de la Salve Regina pour soprano voice
class InstSoprano:
    #Constructeur pour InstSoprano
    def __init__(self, feedback=0.08):
        self.feedback = feedback
        self.envelope = Fader(fadein=0.3, fadeout=0.05, mul = 0.5)
        self.soprano = Voice(freq=100, register=soprano_formants, mul=self.envelope)

    # Cette fonction est appelee pour jouer une note.
    def play(self, freq, dur, amp):
        self.soprano.setFreq(freq)
        self.envelope.dur = dur
        self.envelope.mul = amp
        self.envelope.play()
    
    def sig(self):
        return self.soprano.sig()


class SR:
    #Phrases from Salve Regina
    def __init__(self, transpose=0, vol = 1):
    
        pit1 = midiToHz([x + transpose for x in [60, 64, 67, 69, 67]])
        pit2 = midiToHz([x + transpose for x in [67, 69, 71, 72, 67]])
        pit3 = midiToHz([x + transpose for x in [72, 67, 69, 65, 62, 64]])
        pit4 = midiToHz([x + transpose for x in [67, 69, 71, 72]])
        pit5 = midiToHz([x + transpose for x in [67, 69, 72, 71, 69, 67]])
        pit6 = midiToHz([x + transpose for x in [72, 67, 69, 65, 62]])
        pit7 = midiToHz([x + transpose for x in[64, 60, 65, 64, 64, 62, 60]])

# frequence, duree, amplitude
    #Salve Regina 2 fois
        self.notes1 = [(pit1[0], 0.5, 0.05), (pit1[1], 0.5, 0.08), (pit1[2], 0.5, 0.10), (pit1[3], 1.0, 0.15), (pit1[4], 1.5, 0.13)]
    #ad te clamamus
        self.notes2 = [(pit2[0], 0.5, 0.08), (pit2[1], 0.5, 0.10), (pit2[2], 0.5, 0.12), (pit2[3], 1.0, 0.17), (pit2[4], 1.5, 0.15)] 
    #ad te suspiramus
        self.notes3 = [(pit3[0], 0.5, 0.08), (pit3[1], 0.5, 0.07), (pit3[2], 1.5, 0.20), (pit3[3], 0.5, 0.15), (pit3[4], 0.7, 0.13), (pit3[5], 1.5, 0.15)] 
    #Eia ergo
        self.notes4 = [(pit4[0], 0.5, 0.08), (pit4[1], 0.5, 0.10), (pit4[2], 0.5, 0.15), (pit4[3], 1.5, 0.20)]
    #advocata nostra 
        self.notes5 = [(pit5[0], 0.5, 0.08), (pit5[1], 0.5, 0.08), (pit5[2], 0.5, 0.09), (pit5[3], 0.5, 0.08), (pit5[4], 0.7, 0.07), (pit5[5], 1.0, 0.06)]
    #vita dulcedo
        self.notes6 = [(pit6[0], 0.5, 0.08), (pit6[1], 0.5, 0.06), (pit6[2], 0.5, 0.07), (pit6[3], 0.8, 0.06), (pit6[4], 1.0, 0.05)]
    #et spes nostra salve
        self.notes7 = [(pit7[0], 1.5, 0.08), (pit7[1], 1.5, 0.06), (pit7[2], 2.0, 0.15), (pit7[3], 1.0, 0.10), (pit7[4], 1.0, 0.10), (pit7[5], 1.5, 0.08), (pit7[6], 2.0, 0.05)] 
        
#Choice of phrase among the 7 of the Salve Regina
    def chooseMelody(self, mel):
        if mel ==1:
            phrase = self.notes1
        elif mel ==2:
            phrase = self.notes2
        elif mel ==3:
            phrase = self.notes3
        elif mel ==4:
            phrase = self.notes4
        elif mel ==5:
            phrase = self.notes5
        elif mel ==6:
            phrase = self.notes6
        elif mel ==7:
            phrase = self.notes7
                        
        return phrase

# Partition pour la voix de soprano
class PartitionSoprano:
    def __init__(self, mel=1, transpose=0, vol = 1, time=1):
        # instruments
        self.soprano = InstSoprano()
        self.vol=vol
        self.transpose=transpose
        self.time=time
        # Le numero de la melodie
        self.melody = mel
        # Le compte des notes dans la melodie
        self.count = 0
        # melodies
        self.sr = SR(transpose=self.transpose)
        print("Playing soprano melody # %d" % self.melody)

        # La liste de notes a jouer
        self.notes = self.sr.chooseMelody(self.melody)

        # self.newNote est appelee a chaque nouvelle note.
        self.player = Pattern(self.newNote, time=0.5)
        
    def newNote(self):
        # On recupere la note dans la liste et on active une note a l'instrument alto.
        if self.count < len(self.notes): 
            note = self.notes[self.count]
            freq = note[0]
            dur = note[1]
            amp = note[2]*self.vol
            self.soprano.play(freq, dur*self.time, amp)
        # On ajuste le "time" du Pattern pour suivre la sequence rythmique des durees
            self.player.time = dur*self.time

        # On incremente le compte
        self.count += 1
        # Si au bout de la liste...
        if self.count == len(self.notes) + 1:
            # On arrête
            self.player.stop()
            print("Playing soprano melody # %d" % self.melody)
            #self.callback()
            self.count=0
            
            
    # Methode pour activer la partition de la voix soprano.
    def play(self):
        self.player.play()
        

    # Methode pour recuperer le son de la voix soprano .
    def getSound(self):
        return self.soprano.sig()
        
    # Méthode pour changer mélodies
    def setMelody(self, x):
        self.melody = x
        self.notes = self.sr.chooseMelody(self.melody)
       
    # Méthode pour changer le volume
    def setVolume(self, x):
        self.vol=x
        
    # Méthode pour changer le tempo
    def setTime(self, x):
        self.time=x

"""
______________________________________________________________________
##Classes pour Ave Maria Procidana: InstCloche ##
______________________________________________________________________
"""
   
class InstCloche:
    #Constructeur pour InstCloche
    def __init__(self, freqBase=80, amp=1, env=1):
        self.freqs = [x*midiToHz(freqBase) for x in [1, .56, .56+1, .92, .92+1.7, 1.19, 1.7]]
        self.amps = [x*amp  for x in [1,.67, 1, 1.8, 2.67, 1.67, 1.46]]
        self.env_f = [x*env for x in [1, 1/.9, 1/.65, 1/.55, 1/.325, 1/.35, 1/.25]]
        self.env = ExpTable([(0,0), (16, 1), (8191,0)], exp=4)
        self.tableread = TableRead(self.env, freq=self.env_f, loop=0, mul=self.amps)
        self.cloche = Sine(freq=self.freqs, mul=self.tableread)

    # Cette fonction est appelee pour jouer une note.


    def play(self,freq,env ,amp):
        #On recalcule les frequences de base et partiel de la cloche
        self.freqs = [x * freq for x in [1, .56, .56 + 1, .92, .92 + 1.7, 1.19, 1.7]]
        #On recalcule tout les amplitudes de la cloches
        self.amps = [x * amp for x in [1, .67, 1, 1.8, 2.67, 1.67, 1.46]]
        #On recalcule toute les env_f
        self.env_f = [x*env for x in [1, 1/.9, 1/.65, 1/.55, 1/.325, 1/.35, 1/.25]]


        #On applique les changements de l'env_f sur la table
        self.tableread.freq=self.env_f
        self.tableread.mul=self.amps

        #On applique les changements de frequences sur la cloche
        # cette ligne plante...
        self.cloche.freq = self.freqs

        self.tableread.play()


    def sig(self):
            return self.cloche
        
    def out(self):
        self.cloche.out()

    def _play(self):
        self.tableread.play()

class AVMP:
    #Phrases de l'Ave Maria Procidana
    def __init__(self, transpose=0, incvel=0):
    
        pit1 = midiToHz([x + transpose for x in [67, 67, 67, 67, 69, 69, 67, 69, 69, 67, 71, 69, 67, 65, 69, 69, 69, 69, 69, 69, 67, 67,
                            67, 67, 67, 65, 64]])
        pit2 = midiToHz([x + transpose for x in [67, 67, 69, 69, 67, 67, 67, 69, 69, 67, 69, 71, 69, 67, 65, 69,
                            69, 69, 69, 69, 69, 69, 67, 71, 69, 67, 67, 65, 64]])

# frequence, duree, amplitude
    #Madonna delle Grazie...
        self.notes1 = [(pit1[0], 0.6, 0.04), (pit1[1], 0.6, 0.08), (pit1[2], 0.6, 0.05), (pit1[3], 0.6, 0.05), (pit1[4], 0.6, 0.05), 
            (pit1[5], 1.2, 0.08), (pit1[6], 0.6, 0.05), (pit1[7], 0.6, 0.05,), (pit1[8], 0.6, 0.08), (pit1[9], 0.6, 0.05),
            (pit1[10], 0.6, 0.05), (pit1[11], 0.6, 0.05), (pit1[12], 1.2, 0.08), (pit1[13], 0.6, 0.05,), (pit1[14], 0.6, 0.05),
            (pit1[15], 0.6, 0.08), (pit1[16], 0.6, 0.05), (pit1[17], 0.6, 0.05), (pit1[18], 0.6, 0.05,), (pit1[19], 1.2, 0.08),
            (pit1[20], 0.6, 0.05), (pit1[21], 0.6, 0.05), (pit1[22], 0.6, 0.08), (pit1[23], 0.6, 0.05,), (pit1[24], 0.6, 0.05),
            (pit1[25], 0.6, 0.05), (pit1[26], 2.4, 0.08)]
    #Santa Maria
        self.notes2 = [(pit2[0], 0.6, 0.10), (pit2[1], 0.4, 0.10), (pit2[2], 0.2, 0.05), (pit2[3], 0.4, 0.10), (pit2[4], 0.2, 0.05), 
            (pit2[5], 0.2, 0.10), (pit2[6], 0.2, 0.05), (pit2[7], 0.2, 0.05), (pit2[8], 0.2, 0.10), (pit2[9],0.2, 0.05), 
            (pit2[10], 0.2, 0.05), (pit2[11], 0.4, 0.10), (pit2[12], 0.2, 0.05), (pit2[13], 0.6, 0.10), (pit2[14], 0.4, 0.10), (pit2[15], 0.2 ,0.05), 
            (pit2[16], 0.2, 0.10), (pit2[17], 0.2, 0.05), (pit2[18], 0.2, 0.05), (pit2[19], 0.4, 0.10), (pit2[20],0.2 ,0.05), (pit2[21], 0.4, 0.10), 
            (pit2[22], 0.2, 0.05), (pit2[23], 0.4, 0.10), (pit2[24], 0.2, 0.05), (pit2[25], 0.6, 0.10), (pit2[26], 0.4, 0.10), (pit2[27],  0.2, 0.05), 
            (pit2[28], 0.6, 0.10)]

    def chooseMelody(self, mel):
        if mel ==1:
            phrase = self.notes1
        elif mel ==2:
            phrase = self.notes2
        
        return phrase

        print("Playing cloche melody # %d" % self.melody)

# Partition pour cloche
class PartitionCloche:
    def __init__(self, mel=1, transpose=0, vol=1, time=0.5):
        # instruments
        self.cloche1 = InstCloche()
        self.cloche2 = InstCloche()
        self.cloche3 = InstCloche()
        self.cloche4 = InstCloche()
        self.which = 0
        # Le numero de la melodie
        self.melody = mel
        self.transpose=transpose
        self.vol=vol
        self.time=time
    # melodies
        self.avmp = AVMP(transpose=self.transpose)
        self.time=time
        print("Playing cloche melody # %d" % self.melody)
 # Le compte des notes dans la melodie
        self.count = 0
        # La liste de notes a jouer
        self.notes = self.avmp.chooseMelody(self.melody)
        # self.newNote est appelee a chaque nouvelle note.
        self.player = Pattern(self.newNote, time=self.time)

    def newNote(self):
        # On recupere la note dans la liste et on active une note a l'instrument cloche.
        note = self.notes[self.count]
        freq = note[0]
        dur = note[1]
        amp = note[2]*self.vol
        if self.which == 0:
            self.cloche1.play(freq, dur*self.time, amp)
        elif self.which == 1:
            self.cloche2.play(freq, dur*self.time, amp)
        elif self.which == 2:
            self.cloche3.play(freq, dur*self.time, amp)
        elif self.which == 3:
            self.cloche4.play(freq, dur*self.time, amp)
        self.which += 1
        if self.which == 4:
            self.which = 0
        # On ajuste le "time" du Pattern pour suivre la sequence rythmique des durees
        self.player.time = dur*self.time

        # On incremente le compte
        self.count += 1
        # Si au bout de la liste...
        if self.count == len(self.notes):
            # On remet le compte a zero
            self.player.stop()
            
            self.count=0

    # Methode pour activer la partition de cloche.
    def play(self):
        self.player.play()

    # Methode pour recuperer le son de cloche.
    def getSound(self):
        return self.cloche1.sig()+self.cloche2.sig()+self.cloche3.sig()+self.cloche4.sig()

    # Méthode pour changer mélodies
    def setMelody(self, x):
        self.melody = x
        self.notes = self.avmp.chooseMelody(self.melody)
        
    # Méthode pour changer le volume
    def setVolume(self, x):
        self.vol=x
        
    # Méthode pour changer le tempo
    def setTime(self, x):
        self.time=x
